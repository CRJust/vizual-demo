import { createFileRoute } from "@tanstack/react-router";
import { ArrowRight, Leaf, Mail, Scale, Sparkles, Handshake } from "lucide-react";
import beaverCart from "@/assets/beaver-cart.png.asset.json";
import beaverBags from "@/assets/beaver-bags.png.asset.json";

const CONTACT = "contact@beavy.ro";
const PARTNER_MAIL = `mailto:${CONTACT}?subject=${encodeURIComponent("Hai să vorbim — Beavy")}`;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Beavy — Cumpărături chibzuite. Fără risipă." },
      {
        name: "description",
        content:
          "Beavy e un brand românesc la început de drum, cu o misiune simplă: cumpărături făcute cu cap, fără risipă. Contact pentru retaileri și parteneri: contact@beavy.ro.",
      },
      { property: "og:title", content: "Beavy — Cumpărături chibzuite. Fără risipă." },
      { property: "og:description", content: "Un brand românesc despre cumpărături cu cap. Deschiși la dialog cu retaileri și parteneri." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://beavy.ro" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://beavy.ro" }],
  }),
  component: Index,
});

const values = [
  { icon: Scale, title: "Cu bun-simț", text: "Credem că fiecare leu contează și că o decizie bună de cumpărare nu trebuie să fie complicată.", tone: "bg-mint" },
  { icon: Leaf, title: "Fără risipă", text: "Cumpărăm ce ne trebuie, folosim ce cumpărăm. Simplu de spus, merită făcut zi de zi.", tone: "bg-accent" },
  { icon: Sparkles, title: "Cinstit și clar", text: "Vorbim deschis, fără promisiuni umflate — nici către oameni, nici către parteneri.", tone: "bg-secondary" },
];

function Index() {
  return (
    <div className="flex min-h-screen flex-col overflow-x-hidden bg-background text-foreground">
      <header className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-5">
        <a href="/" className="font-display text-3xl font-extrabold tracking-tight text-primary">
          beavy<span className="text-coral">.</span>
        </a>
        <a
          href={PARTNER_MAIL}
          className="rounded-full border-2 border-foreground/10 px-4 py-2 text-sm font-semibold transition-colors hover:border-primary hover:text-primary"
        >
          Scrie-ne
        </a>
      </header>

      <main className="flex-1">
        {/* Hero */}
        <section className="relative mx-auto grid max-w-6xl items-center gap-10 px-6 pb-16 pt-8 md:grid-cols-[1.1fr_1fr] md:pt-14">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full bg-mint px-4 py-1.5 text-sm font-semibold text-forest">
              <span aria-hidden>🌱</span> Un brand românesc, la început de drum
            </span>
            <h1 className="mt-6 font-display text-5xl font-extrabold leading-[0.95] tracking-tight text-forest md:text-7xl">
              Cumpărături <span className="text-primary">chibzuite.</span>
              <br />
              <span className="relative inline-block">
                Fără risipă.
                <span className="absolute -bottom-1 left-0 -z-10 h-4 w-full rounded-full bg-sun/70" aria-hidden />
              </span>
            </h1>
            <p className="mt-7 max-w-lg text-lg leading-relaxed text-muted-foreground">
              Beavy pornește de la o idee simplă: cumpărăturile de zi cu zi pot fi mai liniștite,
              mai atente la buget și mai blânde cu ce aruncăm. Construim pas cu pas, cu răbdare
              — ca un castor. 🦫
            </p>
            <div className="mt-9 flex flex-wrap items-center gap-4">
              <a
                href="#parteneri"
                className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3.5 font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-transform hover:-translate-y-0.5"
              >
                Pentru retaileri <ArrowRight className="h-4 w-4" aria-hidden />
              </a>
              <a href="#misiune" className="font-semibold text-forest underline-offset-4 hover:underline">
                Ce ne dorim
              </a>
            </div>
          </div>

          <div className="relative mx-auto w-full max-w-md">
            <div className="absolute inset-4 rounded-full bg-sun/60 blur-2xl" aria-hidden />
            <div className="absolute right-0 top-6 h-24 w-24 rounded-full bg-coral/30" aria-hidden />
            <div className="absolute -left-2 bottom-10 h-16 w-16 rounded-full bg-mint" aria-hidden />
            <img
              src={beaverCart.url}
              alt="Castorul Beavy împingând un cărucior de cumpărături"
              className="relative w-full drop-shadow-xl"
            />
          </div>
        </section>

        {/* Misiune */}
        <section id="misiune" className="bg-card py-20">
          <div className="mx-auto max-w-6xl px-6">
            <p className="font-semibold text-coral">Misiunea noastră</p>
            <h2 className="mt-2 max-w-2xl font-display text-4xl font-bold leading-tight text-forest md:text-5xl">
              Vrem să facem din „cumpără cu cap” un obicei ușor.
            </h2>
            <p className="mt-5 max-w-2xl text-lg leading-relaxed text-muted-foreground">
              Suntem la început, dar știm încotro mergem: spre un loc în care cumpărăturile inteligente
              devin firești — pentru oameni, pentru magazine și pentru ce rămâne după noi.
            </p>
            <div className="mt-12 grid gap-5 md:grid-cols-3">
              {values.map(({ icon: Icon, title, text, tone }) => (
                <div key={title} className={`rounded-3xl ${tone} p-7 transition-transform hover:-translate-y-1`}>
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-card text-primary">
                    <Icon className="h-6 w-6" aria-hidden />
                  </div>
                  <h3 className="mt-5 font-display text-2xl font-bold text-forest">{title}</h3>
                  <p className="mt-2 leading-relaxed text-foreground/75">{text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Parteneri */}
        <section id="parteneri" className="px-6 py-20">
          <div className="mx-auto grid max-w-6xl items-center gap-10 overflow-hidden rounded-[2.5rem] bg-forest p-8 text-primary-foreground md:grid-cols-[1.2fr_1fr] md:p-14">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full bg-primary-foreground/10 px-4 py-1.5 text-sm font-semibold">
                <Handshake className="h-4 w-4" aria-hidden /> Retaileri & parteneri
              </span>
              <h2 className="mt-5 font-display text-4xl font-bold leading-tight md:text-5xl">
                Hai să stăm de vorbă.
              </h2>
              <p className="mt-5 max-w-lg text-lg leading-relaxed text-primary-foreground/80">
                Căutăm retaileri și parteneri care pun preț pe clienți informați și pe mai puțină
                risipă. Nu avem promisiuni mari de oferit — avem o viziune clară și chef de colaborări
                construite corect, de la zero.
              </p>
              <a
                href={PARTNER_MAIL}
                className="mt-8 inline-flex items-center gap-3 rounded-full bg-sun px-7 py-3.5 font-semibold text-forest transition-transform hover:-translate-y-0.5"
              >
                <Mail className="h-5 w-5" aria-hidden /> {CONTACT}
              </a>
              <p className="mt-4 text-sm text-primary-foreground/60">Citim fiecare mesaj și răspundem personal.</p>
            </div>
            <div className="relative mx-auto w-full max-w-xs">
              <div className="absolute inset-6 rounded-full bg-sun/40 blur-2xl" aria-hidden />
              <img
                src={beaverBags.url}
                alt="Castorul Beavy cu sacoșe colorate de cumpărături"
                className="relative w-full drop-shadow-2xl"
              />
            </div>
          </div>
        </section>
      </main>

      <footer className="pb-10">
        <div className="mx-auto flex max-w-6xl flex-col justify-between gap-3 px-6 text-sm text-muted-foreground md:flex-row">
          <p>
            <span className="font-display text-lg font-extrabold text-primary">beavy</span> · Cumpărături chibzuite. Fără risipă.
          </p>
          <p>beavy.ro · {CONTACT} · © {new Date().getFullYear()}</p>
        </div>
      </footer>
    </div>
  );
}
